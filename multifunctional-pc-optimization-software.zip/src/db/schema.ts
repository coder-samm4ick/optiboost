import { pgTable, text, timestamp, uuid, varchar, boolean } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }).notNull(),
  password: varchar('password', { length: 255 }).notNull(),
  subscription: varchar('subscription', { length: 50 }).notNull().default('free'), // free, pro, pro_plus
  subscriptionExpiry: timestamp('subscription_expiry'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const optimizationHistory = pgTable('optimization_history', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id),
  action: varchar('action', { length: 255 }).notNull(),
  category: varchar('category', { length: 100 }).notNull(), // system, network, privacy, etc.
  timestamp: timestamp('timestamp').defaultNow().notNull(),
  success: boolean('success').notNull().default(true),
});
