'use client';

import { useState } from 'react';
import Link from 'next/link';

type Tab = 'system' | 'network' | 'privacy' | 'performance' | 'advanced';
type SubscriptionType = 'free' | 'pro' | 'pro_plus';

export default function AppPage() {
  const [activeTab, setActiveTab] = useState<Tab>('system');
  const [subscription] = useState<SubscriptionType>('free'); // В реальном приложении это будет из контекста пользователя
  
  // Состояния для переключателей
  const [systemToggles, setSystemToggles] = useState({
    cleanTemp: false,
    cleanRegistry: false,
    optimizeBoot: false,
    defragDisk: false,
  });

  const [networkToggles, setNetworkToggles] = useState({
    dnsOptimize: false,
    clearCache: false,
    tcpOptimize: false,
    vpnProtect: false,
  });

  const [privacyToggles, setPrivacyToggles] = useState({
    clearHistory: false,
    removeTrackers: false,
    secureData: false,
    antiSpyware: false,
  });

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [progress, setProgress] = useState(0);

  const isFeatureLocked = (feature: string) => {
    if (subscription === 'pro_plus') return false;
    if (subscription === 'pro' && ['cleanRegistry', 'dnsOptimize', 'tcpOptimize', 'clearHistory', 'removeTrackers'].includes(feature)) {
      return false;
    }
    return !['cleanTemp', 'clearCache'].includes(feature);
  };

  const handleOptimize = async () => {
    setIsOptimizing(true);
    setProgress(0);
    
    // Симуляция процесса оптимизации
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsOptimizing(false);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="text-white hover:text-blue-300 transition">
                ← Главная
              </Link>
              <h1 className="text-2xl font-bold text-white">⚡ PC Optimizer Pro</h1>
            </div>
            <div className="flex items-center gap-4">
              <div className={`px-4 py-2 rounded-full font-semibold ${
                subscription === 'free' ? 'bg-gray-600 text-white' :
                subscription === 'pro' ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' :
                'bg-gradient-to-r from-yellow-600 to-orange-600 text-white'
              }`}>
                {subscription === 'free' ? '🆓 Free' : 
                 subscription === 'pro' ? '💎 Pro' : 
                 '⭐ Pro Plus'}
              </div>
              {subscription === 'free' && (
                <Link href="/#pricing" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-4 py-2 rounded-lg transition">
                  Обновить до Pro
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab('system')}
            className={`px-6 py-3 rounded-xl font-semibold transition whitespace-nowrap ${
              activeTab === 'system'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-md text-gray-300 hover:bg-white/20'
            }`}
          >
            🖥️ Система
          </button>
          <button
            onClick={() => setActiveTab('network')}
            className={`px-6 py-3 rounded-xl font-semibold transition whitespace-nowrap ${
              activeTab === 'network'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-md text-gray-300 hover:bg-white/20'
            }`}
          >
            🌐 Интернет
          </button>
          <button
            onClick={() => setActiveTab('privacy')}
            className={`px-6 py-3 rounded-xl font-semibold transition whitespace-nowrap ${
              activeTab === 'privacy'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-md text-gray-300 hover:bg-white/20'
            }`}
          >
            🔒 Приватность
          </button>
          <button
            onClick={() => setActiveTab('performance')}
            className={`px-6 py-3 rounded-xl font-semibold transition whitespace-nowrap ${
              activeTab === 'performance'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-md text-gray-300 hover:bg-white/20'
            }`}
          >
            ⚡ Производительность
          </button>
          <button
            onClick={() => setActiveTab('advanced')}
            className={`px-6 py-3 rounded-xl font-semibold transition whitespace-nowrap ${
              activeTab === 'advanced'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-md text-gray-300 hover:bg-white/20'
            }`}
          >
            ⚙️ Дополнительно
          </button>
        </div>

        {/* Content */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Panel */}
          <div className="md:col-span-2">
            <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
              
              {/* System Tab */}
              {activeTab === 'system' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-white mb-6">Оптимизация системы</h2>
                  
                  <ToggleCard
                    title="Очистка временных файлов"
                    description="Удаление временных файлов Windows и неиспользуемых данных"
                    enabled={systemToggles.cleanTemp}
                    locked={isFeatureLocked('cleanTemp')}
                    subscription={subscription}
                    onChange={() => setSystemToggles({...systemToggles, cleanTemp: !systemToggles.cleanTemp})}
                  />
                  
                  <ToggleCard
                    title="Оптимизация реестра"
                    description="Очистка и дефрагментация системного реестра"
                    enabled={systemToggles.cleanRegistry}
                    locked={isFeatureLocked('cleanRegistry')}
                    subscription={subscription}
                    onChange={() => setSystemToggles({...systemToggles, cleanRegistry: !systemToggles.cleanRegistry})}
                  />
                  
                  <ToggleCard
                    title="Ускорение загрузки"
                    description="Оптимизация автозагрузки и служб Windows"
                    enabled={systemToggles.optimizeBoot}
                    locked={isFeatureLocked('optimizeBoot')}
                    subscription={subscription}
                    onChange={() => setSystemToggles({...systemToggles, optimizeBoot: !systemToggles.optimizeBoot})}
                  />
                  
                  <ToggleCard
                    title="Дефрагментация диска"
                    description="Оптимизация размещения файлов на жестком диске"
                    enabled={systemToggles.defragDisk}
                    locked={isFeatureLocked('defragDisk')}
                    subscription={subscription}
                    onChange={() => setSystemToggles({...systemToggles, defragDisk: !systemToggles.defragDisk})}
                  />
                </div>
              )}

              {/* Network Tab */}
              {activeTab === 'network' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-white mb-6">Оптимизация интернета</h2>
                  
                  <ToggleCard
                    title="DNS оптимизация"
                    description="Использование быстрых DNS серверов для ускорения интернета"
                    enabled={networkToggles.dnsOptimize}
                    locked={isFeatureLocked('dnsOptimize')}
                    subscription={subscription}
                    onChange={() => setNetworkToggles({...networkToggles, dnsOptimize: !networkToggles.dnsOptimize})}
                  />
                  
                  <ToggleCard
                    title="Очистка сетевого кэша"
                    description="Удаление кэша DNS и сброс сетевых настроек"
                    enabled={networkToggles.clearCache}
                    locked={isFeatureLocked('clearCache')}
                    subscription={subscription}
                    onChange={() => setNetworkToggles({...networkToggles, clearCache: !networkToggles.clearCache})}
                  />
                  
                  <ToggleCard
                    title="TCP/IP оптимизация"
                    description="Настройка параметров TCP/IP для максимальной скорости"
                    enabled={networkToggles.tcpOptimize}
                    locked={isFeatureLocked('tcpOptimize')}
                    subscription={subscription}
                    onChange={() => setNetworkToggles({...networkToggles, tcpOptimize: !networkToggles.tcpOptimize})}
                  />
                  
                  <ToggleCard
                    title="VPN защита"
                    description="Активация встроенной VPN защиты"
                    enabled={networkToggles.vpnProtect}
                    locked={isFeatureLocked('vpnProtect')}
                    subscription={subscription}
                    onChange={() => setNetworkToggles({...networkToggles, vpnProtect: !networkToggles.vpnProtect})}
                  />
                </div>
              )}

              {/* Privacy Tab */}
              {activeTab === 'privacy' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-white mb-6">Конфиденциальность</h2>
                  
                  <ToggleCard
                    title="Очистка истории"
                    description="Удаление истории браузеров и системных логов"
                    enabled={privacyToggles.clearHistory}
                    locked={isFeatureLocked('clearHistory')}
                    subscription={subscription}
                    onChange={() => setPrivacyToggles({...privacyToggles, clearHistory: !privacyToggles.clearHistory})}
                  />
                  
                  <ToggleCard
                    title="Удаление трекеров"
                    description="Блокировка и удаление отслеживающих cookies"
                    enabled={privacyToggles.removeTrackers}
                    locked={isFeatureLocked('removeTrackers')}
                    subscription={subscription}
                    onChange={() => setPrivacyToggles({...privacyToggles, removeTrackers: !privacyToggles.removeTrackers})}
                  />
                  
                  <ToggleCard
                    title="Защита данных"
                    description="Шифрование личных данных и защита файлов"
                    enabled={privacyToggles.secureData}
                    locked={isFeatureLocked('secureData')}
                    subscription={subscription}
                    onChange={() => setPrivacyToggles({...privacyToggles, secureData: !privacyToggles.secureData})}
                  />
                  
                  <ToggleCard
                    title="Антишпионское ПО"
                    description="Обнаружение и удаление шпионских программ"
                    enabled={privacyToggles.antiSpyware}
                    locked={isFeatureLocked('antiSpyware')}
                    subscription={subscription}
                    onChange={() => setPrivacyToggles({...privacyToggles, antiSpyware: !privacyToggles.antiSpyware})}
                  />
                </div>
              )}

              {/* Performance Tab */}
              {activeTab === 'performance' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-white mb-6">Производительность</h2>
                  
                  <div className="bg-black/20 p-6 rounded-xl">
                    <h3 className="text-xl font-bold text-white mb-4">Системная информация</h3>
                    <div className="grid grid-cols-2 gap-4 text-gray-300">
                      <div>
                        <p className="text-sm text-gray-400">Процессор</p>
                        <p className="font-semibold">Intel Core i7-9700K</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Память</p>
                        <p className="font-semibold">16 GB RAM</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Диск</p>
                        <p className="font-semibold">512 GB SSD</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">GPU</p>
                        <p className="font-semibold">NVIDIA GTX 1660</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/20 p-6 rounded-xl">
                    <h3 className="text-xl font-bold text-white mb-4">Загрузка системы</h3>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm text-gray-300 mb-1">
                          <span>CPU</span>
                          <span>45%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-blue-500 h-2 rounded-full" style={{width: '45%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm text-gray-300 mb-1">
                          <span>RAM</span>
                          <span>62%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-purple-500 h-2 rounded-full" style={{width: '62%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm text-gray-300 mb-1">
                          <span>Диск</span>
                          <span>38%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-green-500 h-2 rounded-full" style={{width: '38%'}}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Advanced Tab */}
              {activeTab === 'advanced' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-white mb-6">Дополнительные настройки</h2>
                  
                  {subscription === 'free' ? (
                    <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 p-8 rounded-xl border border-blue-400/30 text-center">
                      <div className="text-6xl mb-4">🔒</div>
                      <h3 className="text-2xl font-bold text-white mb-4">Требуется Pro подписка</h3>
                      <p className="text-gray-300 mb-6">
                        Расширенные настройки доступны только для Pro и Pro Plus пользователей
                      </p>
                      <Link href="/#pricing" className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-lg font-semibold transition">
                        Обновить до Pro
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="bg-black/20 p-6 rounded-xl">
                        <h3 className="text-xl font-bold text-white mb-4">Планировщик задач</h3>
                        <p className="text-gray-300 mb-4">Автоматическая оптимизация по расписанию</p>
                        <select className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white">
                          <option value="daily">Ежедневно</option>
                          <option value="weekly">Еженедельно</option>
                          <option value="monthly">Ежемесячно</option>
                        </select>
                      </div>

                      <div className="bg-black/20 p-6 rounded-xl">
                        <h3 className="text-xl font-bold text-white mb-4">Резервное копирование</h3>
                        <p className="text-gray-300 mb-4">Создание точки восстановления перед оптимизацией</p>
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" className="w-5 h-5" defaultChecked />
                          <span className="text-white">Включить автоматическое резервное копирование</span>
                        </label>
                      </div>

                      {subscription === 'pro_plus' && (
                        <div className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 p-6 rounded-xl border border-yellow-400/30">
                          <h3 className="text-xl font-bold text-white mb-4">⭐ Эксклюзивно для Pro Plus</h3>
                          <p className="text-gray-300 mb-4">Расширенная аналитика и мониторинг в реальном времени</p>
                          <button className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white px-6 py-2 rounded-lg font-semibold transition">
                            Открыть панель аналитики
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">Быстрые действия</h3>
              
              {isOptimizing ? (
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl mb-2">⚡</div>
                    <p className="text-white font-semibold">Оптимизация...</p>
                    <p className="text-gray-300 text-sm">{progress}%</p>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                      style={{width: `${progress}%`}}
                    ></div>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={handleOptimize}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-4 rounded-xl font-bold text-lg transition transform hover:scale-105 shadow-lg"
                >
                  ▶️ Запустить оптимизацию
                </button>
              )}
            </div>

            {/* Stats */}
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">Статистика</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-300">Освобождено места:</span>
                  <span className="text-white font-semibold">2.4 GB</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Ускорение:</span>
                  <span className="text-green-400 font-semibold">+35%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Оптимизаций:</span>
                  <span className="text-white font-semibold">127</span>
                </div>
              </div>
            </div>

            {/* Upgrade Prompt */}
            {subscription === 'free' && (
              <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 p-6 rounded-2xl border border-blue-400/30">
                <div className="text-center">
                  <div className="text-4xl mb-3">💎</div>
                  <h3 className="text-lg font-bold text-white mb-2">Разблокируйте все функции</h3>
                  <p className="text-gray-300 text-sm mb-4">
                    Получите доступ ко всем инструментам оптимизации
                  </p>
                  <Link href="/#pricing" className="block w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 rounded-lg font-semibold transition">
                    Обновить сейчас
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

interface ToggleCardProps {
  title: string;
  description: string;
  enabled: boolean;
  locked: boolean;
  subscription: SubscriptionType;
  onChange: () => void;
}

function ToggleCard({ title, description, enabled, locked, subscription, onChange }: ToggleCardProps) {
  return (
    <div className={`bg-black/20 p-6 rounded-xl border transition ${
      locked ? 'border-gray-600 opacity-60' : 'border-white/10 hover:border-white/30'
    }`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-bold text-white">{title}</h3>
            {locked && <span className="text-xs bg-yellow-600 px-2 py-1 rounded text-white">🔒 Pro</span>}
          </div>
          <p className="text-gray-300 text-sm">{description}</p>
        </div>
        <div className="ml-4">
          {locked ? (
            <div className="w-14 h-8 bg-gray-600 rounded-full flex items-center justify-center cursor-not-allowed">
              <span className="text-white text-xs">🔒</span>
            </div>
          ) : (
            <button
              onClick={onChange}
              className={`relative w-14 h-8 rounded-full transition ${
                enabled ? 'bg-gradient-to-r from-blue-600 to-purple-600' : 'bg-gray-600'
              }`}
            >
              <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition transform ${
                enabled ? 'translate-x-6' : 'translate-x-0'
              }`}></div>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
