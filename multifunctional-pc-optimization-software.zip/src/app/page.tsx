import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Navigation */}
      <nav className="bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold text-white">⚡ PC Optimizer Pro</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/features" className="text-white hover:text-blue-300 transition">
                Возможности
              </Link>
              <Link href="/pricing" className="text-white hover:text-blue-300 transition">
                Тарифы
              </Link>
              <Link href="/download" className="text-white hover:text-blue-300 transition">
                Скачать
              </Link>
              <Link href="/app" className="text-white hover:text-blue-300 transition">
                Приложение
              </Link>
              <Link href="/login" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                Войти
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
            Оптимизация ПК на
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"> новом уровне</span>
          </h1>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Профессиональный инструмент для оптимизации Windows, ускорения интернета и повышения производительности вашего компьютера
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/app" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl text-lg font-semibold transition transform hover:scale-105 shadow-xl">
              🚀 Запустить приложение
            </Link>
            <a href="#pricing" className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white px-8 py-4 rounded-xl text-lg font-semibold transition border border-white/20">
              💎 Посмотреть тарифы
            </a>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 hover:bg-white/15 transition">
            <div className="text-4xl mb-4">🖥️</div>
            <h3 className="text-2xl font-bold text-white mb-3">Оптимизация системы</h3>
            <p className="text-gray-300">Очистка мусора, оптимизация реестра, ускорение загрузки Windows</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 hover:bg-white/15 transition">
            <div className="text-4xl mb-4">🌐</div>
            <h3 className="text-2xl font-bold text-white mb-3">Ускорение интернета</h3>
            <p className="text-gray-300">DNS оптимизация, очистка кэша, настройка сетевых параметров</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 hover:bg-white/15 transition">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-2xl font-bold text-white mb-3">Конфиденциальность</h3>
            <p className="text-gray-300">Удаление следов, защита данных, контроль приватности</p>
          </div>
        </div>

        {/* Pricing Section */}
        <div id="pricing" className="mt-32">
          <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-16">
            Выберите свой тариф
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Free */}
            <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 hover:border-white/40 transition">
              <h3 className="text-2xl font-bold text-white mb-2">Free</h3>
              <div className="text-4xl font-bold text-white mb-6">
                0₽<span className="text-lg text-gray-400">/мес</span>
              </div>
              <ul className="space-y-3 mb-8 text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Базовая очистка системы</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Очистка кэша браузера</span>
                </li>
                <li className="flex items-start opacity-50">
                  <span className="mr-2">✗</span>
                  <span>Оптимизация реестра</span>
                </li>
                <li className="flex items-start opacity-50">
                  <span className="mr-2">✗</span>
                  <span>DNS ускорение</span>
                </li>
              </ul>
              <Link href="/app" className="block w-full bg-white/20 hover:bg-white/30 text-white py-3 rounded-lg text-center font-semibold transition">
                Начать бесплатно
              </Link>
            </div>

            {/* Pro */}
            <div className="bg-gradient-to-br from-blue-600/30 to-purple-600/30 backdrop-blur-md p-8 rounded-2xl border-2 border-blue-400 transform scale-105 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-blue-500 to-purple-500 px-4 py-1 rounded-full text-white text-sm font-bold">
                Популярный
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Pro</h3>
              <div className="text-4xl font-bold text-white mb-6">
                499₽<span className="text-lg text-gray-400">/мес</span>
              </div>
              <ul className="space-y-3 mb-8 text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Все функции Free</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Оптимизация реестра</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>DNS ускорение</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Автоматическая оптимизация</span>
                </li>
                <li className="flex items-start opacity-50">
                  <span className="mr-2">✗</span>
                  <span>Приоритетная поддержка</span>
                </li>
              </ul>
              <Link href="/app" className="block w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 rounded-lg text-center font-semibold transition">
                Выбрать Pro
              </Link>
            </div>

            {/* Pro Plus */}
            <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-yellow-400/50 hover:border-yellow-400 transition">
              <h3 className="text-2xl font-bold text-white mb-2">Pro Plus</h3>
              <div className="text-4xl font-bold text-white mb-6">
                999₽<span className="text-lg text-gray-400">/мес</span>
              </div>
              <ul className="space-y-3 mb-8 text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Все функции Pro</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Приоритетная поддержка 24/7</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Расширенная аналитика</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>VPN защита</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Безлимитные устройства</span>
                </li>
              </ul>
              <Link href="/app" className="block w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white py-3 rounded-lg text-center font-semibold transition">
                Выбрать Pro Plus
              </Link>
            </div>
          </div>
        </div>

        {/* Download Section */}
        <div className="mt-32 bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-md p-12 rounded-3xl border border-white/20">
          <h2 className="text-4xl font-bold text-white text-center mb-8">
            📥 Скачать приложение
          </h2>
          <p className="text-center text-gray-300 mb-8 text-lg">
            Доступно для Windows 10/11
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/download" className="bg-white/20 hover:bg-white/30 text-white px-8 py-4 rounded-xl font-semibold transition flex items-center justify-center gap-2">
              <span>🆓</span>
              <span>Скачать Free версию</span>
            </Link>
            <Link href="/download" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-semibold transition flex items-center justify-center gap-2">
              <span>💎</span>
              <span>Скачать Pro версию</span>
            </Link>
            <Link href="/download" className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white px-8 py-4 rounded-xl font-semibold transition flex items-center justify-center gap-2">
              <span>⭐</span>
              <span>Скачать Pro Plus</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 mt-20 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>© 2024 PC Optimizer Pro. Все права защищены.</p>
        </div>
      </footer>
    </div>
  );
}
