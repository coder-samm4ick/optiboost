'use client';

import Link from 'next/link';

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Navigation */}
      <nav className="bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-white">
              ⚡ PC Optimizer Pro
            </Link>
            <div className="flex items-center gap-4">
              <Link href="/app" className="text-white hover:text-blue-300 transition">
                Приложение
              </Link>
              <Link href="/login" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                Войти
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Выберите идеальный тариф
          </h1>
          <p className="text-xl text-gray-300">
            Профессиональные инструменты для оптимизации вашего ПК
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {/* Free Plan */}
          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
            <div className="text-center mb-6">
              <div className="text-5xl mb-4">🆓</div>
              <h2 className="text-3xl font-bold text-white mb-2">Free</h2>
              <div className="text-5xl font-bold text-white mb-2">
                0₽
              </div>
              <p className="text-gray-300">Навсегда бесплатно</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-gray-300">Базовая очистка временных файлов</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-gray-300">Очистка кэша браузера</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-gray-300">Мониторинг производительности</span>
              </div>
              <div className="flex items-start gap-3 opacity-50">
                <span className="text-red-400 text-xl">✗</span>
                <span className="text-gray-400">Оптимизация реестра</span>
              </div>
              <div className="flex items-start gap-3 opacity-50">
                <span className="text-red-400 text-xl">✗</span>
                <span className="text-gray-400">DNS ускорение</span>
              </div>
              <div className="flex items-start gap-3 opacity-50">
                <span className="text-red-400 text-xl">✗</span>
                <span className="text-gray-400">Приоритетная поддержка</span>
              </div>
            </div>

            <Link 
              href="/app"
              className="block w-full bg-white/20 hover:bg-white/30 text-white py-4 rounded-xl text-center font-bold text-lg transition"
            >
              Начать бесплатно
            </Link>
          </div>

          {/* Pro Plan */}
          <div className="bg-gradient-to-br from-blue-600/30 to-purple-600/30 backdrop-blur-md p-8 rounded-2xl border-2 border-blue-400 transform scale-105 relative shadow-2xl">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-blue-500 to-purple-500 px-6 py-2 rounded-full text-white font-bold shadow-lg">
              🔥 Самый популярный
            </div>

            <div className="text-center mb-6 mt-2">
              <div className="text-5xl mb-4">💎</div>
              <h2 className="text-3xl font-bold text-white mb-2">Pro</h2>
              <div className="text-5xl font-bold text-white mb-2">
                499₽
              </div>
              <p className="text-gray-300">в месяц</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white font-semibold">Все функции Free</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Оптимизация реестра Windows</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">DNS ускорение интернета</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">TCP/IP оптимизация</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Автоматическая оптимизация</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Удаление трекеров и истории</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Планировщик задач</span>
              </div>
            </div>

            <Link 
              href="/app"
              className="block w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-4 rounded-xl text-center font-bold text-lg transition shadow-lg"
            >
              Выбрать Pro
            </Link>
          </div>

          {/* Pro Plus Plan */}
          <div className="bg-gradient-to-br from-yellow-600/20 to-orange-600/20 backdrop-blur-md p-8 rounded-2xl border-2 border-yellow-400">
            <div className="text-center mb-6">
              <div className="text-5xl mb-4">⭐</div>
              <h2 className="text-3xl font-bold text-white mb-2">Pro Plus</h2>
              <div className="text-5xl font-bold text-white mb-2">
                999₽
              </div>
              <p className="text-gray-300">в месяц</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white font-semibold">Все функции Pro</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">VPN защита</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Расширенная аналитика</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Приоритетная поддержка 24/7</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Антишпионское ПО</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Защита и шифрование данных</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Безлимитные устройства</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">✓</span>
                <span className="text-white">Резервное копирование</span>
              </div>
            </div>

            <Link 
              href="/app"
              className="block w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white py-4 rounded-xl text-center font-bold text-lg transition shadow-lg"
            >
              Выбрать Pro Plus
            </Link>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-8">
            Сравнение функций
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/20">
                  <th className="py-4 px-4 text-gray-300 font-semibold">Функция</th>
                  <th className="py-4 px-4 text-center text-gray-300 font-semibold">Free</th>
                  <th className="py-4 px-4 text-center text-blue-400 font-semibold">Pro</th>
                  <th className="py-4 px-4 text-center text-yellow-400 font-semibold">Pro Plus</th>
                </tr>
              </thead>
              <tbody className="text-gray-300">
                <tr className="border-b border-white/10">
                  <td className="py-4 px-4">Очистка временных файлов</td>
                  <td className="py-4 px-4 text-center">✓</td>
                  <td className="py-4 px-4 text-center">✓</td>
                  <td className="py-4 px-4 text-center">✓</td>
                </tr>
                <tr className="border-b border-white/10">
                  <td className="py-4 px-4">Оптимизация реестра</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center">✓</td>
                  <td className="py-4 px-4 text-center">✓</td>
                </tr>
                <tr className="border-b border-white/10">
                  <td className="py-4 px-4">DNS ускорение</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center">✓</td>
                  <td className="py-4 px-4 text-center">✓</td>
                </tr>
                <tr className="border-b border-white/10">
                  <td className="py-4 px-4">VPN защита</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center">✓</td>
                </tr>
                <tr className="border-b border-white/10">
                  <td className="py-4 px-4">Приоритетная поддержка</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center text-gray-600">✗</td>
                  <td className="py-4 px-4 text-center">24/7</td>
                </tr>
                <tr>
                  <td className="py-4 px-4">Количество устройств</td>
                  <td className="py-4 px-4 text-center">1</td>
                  <td className="py-4 px-4 text-center">3</td>
                  <td className="py-4 px-4 text-center">Безлимит</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
          <h2 className="text-3xl font-bold text-white text-center mb-8">
            Часто задаваемые вопросы
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold text-white mb-2">
                Можно ли перейти с Free на Pro?
              </h3>
              <p className="text-gray-300">
                Да, вы можете обновить подписку в любое время из настроек приложения.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white mb-2">
                Есть ли гарантия возврата денег?
              </h3>
              <p className="text-gray-300">
                Да, мы предлагаем 30-дневную гарантию возврата денег без вопросов.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white mb-2">
                Безопасно ли использовать PC Optimizer Pro?
              </h3>
              <p className="text-gray-300">
                Абсолютно! Все операции безопасны и создаются точки восстановления перед изменениями.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 py-8 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>© 2024 PC Optimizer Pro. Все права защищены.</p>
        </div>
      </footer>
    </div>
  );
}
