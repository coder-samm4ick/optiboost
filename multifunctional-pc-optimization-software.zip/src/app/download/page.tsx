'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function DownloadPage() {
  const [selectedVersion, setSelectedVersion] = useState<'free' | 'pro' | 'pro_plus'>('free');

  const downloadVersions = {
    free: {
      name: 'Free',
      size: '45.2 MB',
      features: ['Базовая оптимизация', 'Очистка кэша', 'Мониторинг системы'],
      icon: '🆓',
      color: 'gray',
    },
    pro: {
      name: 'Pro',
      size: '52.8 MB',
      features: ['Все функции Free', 'Оптимизация реестра', 'DNS ускорение', 'Автоматизация'],
      icon: '💎',
      color: 'blue',
    },
    pro_plus: {
      name: 'Pro Plus',
      size: '68.5 MB',
      features: ['Все функции Pro', 'VPN защита', 'Расширенная аналитика', 'Приоритетная поддержка'],
      icon: '⭐',
      color: 'yellow',
    },
  };

  const handleDownload = (version: string) => {
    // В реальном приложении здесь будет логика скачивания
    alert(`Скачивание ${version} версии начнется в ближайшее время...`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Navigation */}
      <nav className="bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-white">
              ⚡ PC Optimizer Pro
            </Link>
            <div className="flex items-center gap-4">
              <Link href="/pricing" className="text-white hover:text-blue-300 transition">
                Тарифы
              </Link>
              <Link href="/app" className="text-white hover:text-blue-300 transition">
                Приложение
              </Link>
              <Link href="/login" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                Войти
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            📥 Скачать PC Optimizer Pro
          </h1>
          <p className="text-xl text-gray-300">
            Доступно для Windows 10/11 (64-bit)
          </p>
        </div>

        {/* Version Selector */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {Object.entries(downloadVersions).map(([key, version]) => (
            <button
              key={key}
              onClick={() => setSelectedVersion(key as any)}
              className={`p-6 rounded-2xl border-2 transition transform hover:scale-105 ${
                selectedVersion === key
                  ? 'bg-white/20 border-white/60 shadow-2xl'
                  : 'bg-white/10 border-white/20 hover:bg-white/15'
              }`}
            >
              <div className="text-5xl mb-4">{version.icon}</div>
              <h3 className="text-2xl font-bold text-white mb-2">{version.name}</h3>
              <p className="text-gray-300 text-sm mb-4">{version.size}</p>
              <ul className="text-left text-gray-300 text-sm space-y-2">
                {version.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-green-400">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </button>
          ))}
        </div>

        {/* Download Section */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-md p-12 rounded-3xl border border-white/20 mb-12">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">
              {downloadVersions[selectedVersion].icon}
            </div>
            <h2 className="text-4xl font-bold text-white mb-2">
              PC Optimizer Pro {downloadVersions[selectedVersion].name}
            </h2>
            <p className="text-gray-300 text-lg">
              Версия 2.5.1 • {downloadVersions[selectedVersion].size} • Windows 10/11
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <button
              onClick={() => handleDownload(selectedVersion)}
              className={`px-12 py-5 rounded-xl font-bold text-xl transition transform hover:scale-105 shadow-2xl ${
                selectedVersion === 'free'
                  ? 'bg-white/20 hover:bg-white/30 text-white'
                  : selectedVersion === 'pro'
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white'
                  : 'bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white'
              }`}
            >
              ⬇️ Скачать для Windows
            </button>
          </div>

          <div className="text-center text-gray-300 text-sm">
            <p>Нажимая "Скачать", вы соглашаетесь с условиями использования</p>
          </div>
        </div>

        {/* System Requirements */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-6">
              💻 Системные требования
            </h3>
            <div className="space-y-4 text-gray-300">
              <div className="flex items-start gap-3">
                <span className="text-blue-400">•</span>
                <div>
                  <p className="font-semibold text-white">Операционная система</p>
                  <p>Windows 10/11 (64-bit)</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-blue-400">•</span>
                <div>
                  <p className="font-semibold text-white">Процессор</p>
                  <p>Intel Core i3 или AMD эквивалент</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-blue-400">•</span>
                <div>
                  <p className="font-semibold text-white">Оперативная память</p>
                  <p>4 GB RAM (рекомендуется 8 GB)</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-blue-400">•</span>
                <div>
                  <p className="font-semibold text-white">Дисковое пространство</p>
                  <p>200 MB свободного места</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-blue-400">•</span>
                <div>
                  <p className="font-semibold text-white">Интернет</p>
                  <p>Требуется для активации и обновлений</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-6">
              📋 Что нового в версии 2.5.1
            </h3>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Улучшенная скорость оптимизации на 40%</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Новый алгоритм очистки реестра</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Поддержка Windows 11 23H2</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Обновленный интерфейс с темной темой</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Исправлены ошибки и улучшена стабильность</span>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-400">✓</span>
                <span>Добавлен новый модуль VPN защиты (Pro Plus)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Installation Guide */}
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 mb-12">
          <h3 className="text-3xl font-bold text-white mb-8 text-center">
            🔧 Инструкция по установке
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                1
              </div>
              <h4 className="text-white font-semibold mb-2">Скачайте установщик</h4>
              <p className="text-gray-300 text-sm">Выберите нужную версию и скачайте .exe файл</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                2
              </div>
              <h4 className="text-white font-semibold mb-2">Запустите установщик</h4>
              <p className="text-gray-300 text-sm">Откройте скачанный файл PCOptimizerPro.exe</p>
            </div>
            <div className="text-center">
              <div className="bg-indigo-600 w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                3
              </div>
              <h4 className="text-white font-semibold mb-2">Следуйте инструкциям</h4>
              <p className="text-gray-300 text-sm">Выберите путь установки и подтвердите</p>
            </div>
            <div className="text-center">
              <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                4
              </div>
              <h4 className="text-white font-semibold mb-2">Готово!</h4>
              <p className="text-gray-300 text-sm">Запустите приложение и начните оптимизацию</p>
            </div>
          </div>
        </div>

        {/* Other Platforms */}
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-md p-8 rounded-2xl border border-purple-400/30 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            🌐 Веб-версия также доступна
          </h3>
          <p className="text-gray-300 mb-6">
            Не хотите скачивать? Используйте нашу веб-версию прямо в браузере!
          </p>
          <Link
            href="/app"
            className="inline-block bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-lg font-semibold transition"
          >
            Открыть веб-версию
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 py-8 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>© 2024 PC Optimizer Pro. Все права защищены.</p>
        </div>
      </footer>
    </div>
  );
}
