'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function DashboardPage() {
  const [subscription, setSubscription] = useState<'free' | 'pro' | 'pro_plus'>('free');
  const [stats] = useState({
    optimizations: 127,
    spaceFreed: 2.4,
    speedImprovement: 35,
    lastOptimization: '2 часа назад',
  });

  const handleUpgrade = (plan: 'free' | 'pro' | 'pro_plus') => {
    // В реальном приложении здесь будет API запрос
    setSubscription(plan);
    alert(`Подписка обновлена на ${plan === 'pro' ? 'Pro' : plan === 'pro_plus' ? 'Pro Plus' : 'Free'}!`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <Link href="/" className="text-2xl font-bold text-white">
                ⚡ PC Optimizer Pro
              </Link>
              <nav className="hidden md:flex gap-6">
                <Link href="/app" className="text-gray-300 hover:text-white transition">
                  Приложение
                </Link>
                <Link href="/dashboard" className="text-white font-semibold">
                  Дэшборд
                </Link>
                <Link href="/pricing" className="text-gray-300 hover:text-white transition">
                  Тарифы
                </Link>
              </nav>
            </div>
            <div className="flex items-center gap-4">
              <div className={`px-4 py-2 rounded-full font-semibold ${
                subscription === 'free' ? 'bg-gray-600 text-white' :
                subscription === 'pro' ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' :
                'bg-gradient-to-r from-yellow-600 to-orange-600 text-white'
              }`}>
                {subscription === 'free' ? '🆓 Free' : 
                 subscription === 'pro' ? '💎 Pro' : 
                 '⭐ Pro Plus'}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-white mb-8">Дэшборд</h1>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 backdrop-blur-md p-6 rounded-2xl border border-blue-400/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-300 text-sm font-semibold">Оптимизаций</span>
              <span className="text-3xl">🔧</span>
            </div>
            <div className="text-4xl font-bold text-white mb-1">{stats.optimizations}</div>
            <div className="text-blue-300 text-sm">всего выполнено</div>
          </div>

          <div className="bg-gradient-to-br from-green-600/20 to-green-800/20 backdrop-blur-md p-6 rounded-2xl border border-green-400/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-green-300 text-sm font-semibold">Освобождено</span>
              <span className="text-3xl">💾</span>
            </div>
            <div className="text-4xl font-bold text-white mb-1">{stats.spaceFreed} GB</div>
            <div className="text-green-300 text-sm">дискового пространства</div>
          </div>

          <div className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-md p-6 rounded-2xl border border-purple-400/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm font-semibold">Ускорение</span>
              <span className="text-3xl">⚡</span>
            </div>
            <div className="text-4xl font-bold text-white mb-1">+{stats.speedImprovement}%</div>
            <div className="text-purple-300 text-sm">производительности</div>
          </div>

          <div className="bg-gradient-to-br from-orange-600/20 to-orange-800/20 backdrop-blur-md p-6 rounded-2xl border border-orange-400/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-orange-300 text-sm font-semibold">Последняя</span>
              <span className="text-3xl">⏱️</span>
            </div>
            <div className="text-2xl font-bold text-white mb-1">{stats.lastOptimization}</div>
            <div className="text-orange-300 text-sm">оптимизация</div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Subscription Info */}
          <div className="lg:col-span-2">
            <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">Ваша подписка</h2>
              
              <div className={`p-6 rounded-xl mb-6 ${
                subscription === 'free' ? 'bg-gray-700/50' :
                subscription === 'pro' ? 'bg-gradient-to-r from-blue-600/30 to-purple-600/30' :
                'bg-gradient-to-r from-yellow-600/30 to-orange-600/30'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-5xl">
                      {subscription === 'free' ? '🆓' : 
                       subscription === 'pro' ? '💎' : '⭐'}
                    </span>
                    <div>
                      <h3 className="text-3xl font-bold text-white">
                        {subscription === 'free' ? 'Free' : 
                         subscription === 'pro' ? 'Pro' : 'Pro Plus'}
                      </h3>
                      <p className="text-gray-300">
                        {subscription === 'free' ? 'Бесплатный план' :
                         subscription === 'pro' ? '499₽/месяц' : '999₽/месяц'}
                      </p>
                    </div>
                  </div>
                  {subscription !== 'free' && (
                    <div className="text-right">
                      <p className="text-white font-semibold">Активна до</p>
                      <p className="text-gray-300">15 января 2025</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2 text-gray-300">
                  {subscription === 'free' ? (
                    <>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Базовая оптимизация</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Очистка кэша</span>
                      </div>
                      <div className="flex items-center gap-2 opacity-50">
                        <span className="text-red-400">✗</span>
                        <span>Расширенные функции</span>
                      </div>
                    </>
                  ) : subscription === 'pro' ? (
                    <>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Все базовые функции</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Оптимизация реестра</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>DNS ускорение</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Автоматизация</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Все функции Pro</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>VPN защита</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Приоритетная поддержка 24/7</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">✓</span>
                        <span>Безлимитные устройства</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {subscription !== 'pro_plus' && (
                <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 p-6 rounded-xl border border-blue-400/30">
                  <h3 className="text-xl font-bold text-white mb-3">
                    {subscription === 'free' ? '💎 Обновите до Pro' : '⭐ Обновите до Pro Plus'}
                  </h3>
                  <p className="text-gray-300 mb-4">
                    {subscription === 'free' 
                      ? 'Получите доступ ко всем профессиональным инструментам оптимизации'
                      : 'Получите максимальную защиту и приоритетную поддержку 24/7'
                    }
                  </p>
                  <div className="flex gap-4">
                    {subscription === 'free' && (
                      <button
                        onClick={() => handleUpgrade('pro')}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-lg font-semibold transition"
                      >
                        Обновить до Pro
                      </button>
                    )}
                    <button
                      onClick={() => handleUpgrade('pro_plus')}
                      className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white px-6 py-2 rounded-lg font-semibold transition"
                    >
                      Обновить до Pro Plus
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Recent Activity */}
            <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">Последняя активность</h2>
              <div className="space-y-4">
                {[
                  { action: 'Очистка временных файлов', time: '2 часа назад', size: '1.2 GB', icon: '🗑️' },
                  { action: 'DNS оптимизация', time: '1 день назад', size: '+15% скорость', icon: '🌐' },
                  { action: 'Оптимизация реестра', time: '2 дня назад', size: '450 MB', icon: '⚙️' },
                  { action: 'Очистка кэша браузера', time: '3 дня назад', size: '320 MB', icon: '🧹' },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-black/20 rounded-lg">
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{item.icon}</span>
                      <div>
                        <p className="text-white font-semibold">{item.action}</p>
                        <p className="text-gray-400 text-sm">{item.time}</p>
                      </div>
                    </div>
                    <div className="text-green-400 font-semibold">{item.size}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">Быстрые действия</h3>
              <div className="space-y-3">
                <Link
                  href="/app"
                  className="block w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-3 rounded-lg font-semibold text-center transition"
                >
                  ▶️ Оптимизировать сейчас
                </Link>
                <Link
                  href="/download"
                  className="block w-full bg-white/20 hover:bg-white/30 text-white py-3 rounded-lg font-semibold text-center transition"
                >
                  📥 Скачать приложение
                </Link>
                <Link
                  href="/pricing"
                  className="block w-full bg-white/20 hover:bg-white/30 text-white py-3 rounded-lg font-semibold text-center transition"
                >
                  💎 Сменить тариф
                </Link>
              </div>
            </div>

            {/* System Status */}
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">Статус системы</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm text-gray-300 mb-2">
                    <span>Здоровье системы</span>
                    <span className="text-green-400 font-semibold">Отлично</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{width: '92%'}}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm text-gray-300 mb-2">
                    <span>Защита</span>
                    <span className="text-blue-400 font-semibold">Активна</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{width: '100%'}}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm text-gray-300 mb-2">
                    <span>Производительность</span>
                    <span className="text-purple-400 font-semibold">Высокая</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{width: '85%'}}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Support */}
            <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-md p-6 rounded-2xl border border-purple-400/30">
              <h3 className="text-xl font-bold text-white mb-3">💬 Нужна помощь?</h3>
              <p className="text-gray-300 text-sm mb-4">
                Наша команда поддержки всегда готова помочь
              </p>
              <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 rounded-lg font-semibold transition">
                Связаться с поддержкой
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
