import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { optimizationHistory } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, action, category } = body;

    if (!userId || !action || !category) {
      return NextResponse.json(
        { error: 'Все поля обязательны' },
        { status: 400 }
      );
    }

    // Сохранение истории оптимизации
    const record = await db.insert(optimizationHistory).values({
      userId,
      action,
      category,
      success: true,
    }).returning();

    return NextResponse.json({
      success: true,
      record: record[0],
    });
  } catch (error) {
    console.error('Optimization error:', error);
    return NextResponse.json(
      { error: 'Ошибка оптимизации' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'userId обязателен' },
        { status: 400 }
      );
    }

    // Получение истории оптимизации
    const history = await db.select()
      .from(optimizationHistory)
      .where(eq(optimizationHistory.userId, userId))
      .orderBy(desc(optimizationHistory.timestamp))
      .limit(50);

    return NextResponse.json({
      success: true,
      history,
    });
  } catch (error) {
    console.error('Get history error:', error);
    return NextResponse.json(
      { error: 'Ошибка получения истории' },
      { status: 500 }
    );
  }
}
