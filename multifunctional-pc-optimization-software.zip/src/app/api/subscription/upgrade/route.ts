import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, subscription } = body;

    if (!userId || !subscription) {
      return NextResponse.json(
        { error: 'userId и subscription обязательны' },
        { status: 400 }
      );
    }

    if (!['free', 'pro', 'pro_plus'].includes(subscription)) {
      return NextResponse.json(
        { error: 'Неверный тип подписки' },
        { status: 400 }
      );
    }

    // Установка срока действия подписки (30 дней для платных)
    const subscriptionExpiry = subscription !== 'free' 
      ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) 
      : null;

    // Обновление подписки пользователя
    const updatedUser = await db.update(users)
      .set({ 
        subscription,
        subscriptionExpiry,
      })
      .where(eq(users.id, userId))
      .returning();

    if (updatedUser.length === 0) {
      return NextResponse.json(
        { error: 'Пользователь не найден' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      user: {
        id: updatedUser[0].id,
        email: updatedUser[0].email,
        name: updatedUser[0].name,
        subscription: updatedUser[0].subscription,
        subscriptionExpiry: updatedUser[0].subscriptionExpiry,
      },
    });
  } catch (error) {
    console.error('Subscription upgrade error:', error);
    return NextResponse.json(
      { error: 'Ошибка обновления подписки' },
      { status: 500 }
    );
  }
}
