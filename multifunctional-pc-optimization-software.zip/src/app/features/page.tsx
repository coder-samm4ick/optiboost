import Link from 'next/link';

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Navigation */}
      <nav className="bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-white">
              ⚡ PC Optimizer Pro
            </Link>
            <div className="flex items-center gap-4">
              <Link href="/pricing" className="text-white hover:text-blue-300 transition">
                Тарифы
              </Link>
              <Link href="/download" className="text-white hover:text-blue-300 transition">
                Скачать
              </Link>
              <Link href="/login" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                Войти
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Все возможности PC Optimizer Pro
          </h1>
          <p className="text-xl text-gray-300">
            Мощные инструменты для максимальной производительности
          </p>
        </div>

        {/* System Optimization */}
        <div className="mb-20">
          <div className="flex items-center gap-4 mb-8">
            <span className="text-6xl">🖥️</span>
            <h2 className="text-4xl font-bold text-white">Оптимизация системы</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <FeatureCard
              icon="🗑️"
              title="Очистка временных файлов"
              description="Автоматическое удаление временных файлов Windows, кэша приложений и неиспользуемых данных. Освобождает до 50% дискового пространства."
              features={[
                'Очистка папки Temp',
                'Удаление кэша обновлений',
                'Очистка корзины',
                'Удаление старых логов',
              ]}
              tier="free"
            />
            <FeatureCard
              icon="⚙️"
              title="Оптимизация реестра Windows"
              description="Сканирование и исправление ошибок в системном реестре. Удаление битых ссылок и неиспользуемых ключей."
              features={[
                'Поиск битых ссылок',
                'Дефрагментация реестра',
                'Резервное копирование',
                'Восстановление по одному клику',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="🚀"
              title="Ускорение загрузки Windows"
              description="Оптимизация автозагрузки и отключение ненужных служб для сокращения времени запуска системы до 60%."
              features={[
                'Управление автозагрузкой',
                'Отключение ненужных служб',
                'Оптимизация порядка загрузки',
                'Мониторинг времени запуска',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="💿"
              title="Дефрагментация диска"
              description="Оптимизация размещения файлов на жестком диске для ускорения доступа к данным."
              features={[
                'Анализ фрагментации',
                'Умная дефрагментация',
                'Оптимизация SSD',
                'Планировщик задач',
              ]}
              tier="pro"
            />
          </div>
        </div>

        {/* Network Optimization */}
        <div className="mb-20">
          <div className="flex items-center gap-4 mb-8">
            <span className="text-6xl">🌐</span>
            <h2 className="text-4xl font-bold text-white">Оптимизация интернета</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <FeatureCard
              icon="🔍"
              title="DNS оптимизация"
              description="Автоматический выбор самых быстрых DNS серверов для ускорения загрузки веб-страниц до 200%."
              features={[
                'Тестирование скорости DNS',
                'Cloudflare DNS (1.1.1.1)',
                'Google DNS (8.8.8.8)',
                'Автоматическое переключение',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="🧹"
              title="Очистка сетевого кэша"
              description="Сброс кэша DNS и обновление сетевых настроек для решения проблем с подключением."
              features={[
                'Очистка DNS кэша',
                'Сброс TCP/IP стека',
                'Обновление IP адреса',
                'Сброс Winsock',
              ]}
              tier="free"
            />
            <FeatureCard
              icon="⚡"
              title="TCP/IP оптимизация"
              description="Тонкая настройка параметров TCP/IP для максимальной скорости передачи данных."
              features={[
                'Оптимизация MTU',
                'Настройка TCP Window',
                'Отключение bandwidth throttling',
                'QoS оптимизация',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="🔐"
              title="VPN защита"
              description="Встроенная VPN защита для безопасного и анонимного интернет-серфинга."
              features={[
                'Военное шифрование AES-256',
                'Серверы в 50+ странах',
                'Блокировка рекламы',
                'Kill Switch защита',
              ]}
              tier="pro_plus"
            />
          </div>
        </div>

        {/* Privacy */}
        <div className="mb-20">
          <div className="flex items-center gap-4 mb-8">
            <span className="text-6xl">🔒</span>
            <h2 className="text-4xl font-bold text-white">Конфиденциальность и защита</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <FeatureCard
              icon="🕵️"
              title="Очистка истории"
              description="Удаление следов активности из браузеров и системных логов для полной конфиденциальности."
              features={[
                'История всех браузеров',
                'Cookies и кэш',
                'Недавние документы',
                'История поиска Windows',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="🚫"
              title="Удаление трекеров"
              description="Обнаружение и блокировка отслеживающих cookies и скриптов."
              features={[
                'Блокировка трекеров',
                'Удаление cookies',
                'Защита от фингерпринтинга',
                'Блокировка телеметрии',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="🛡️"
              title="Защита данных"
              description="Шифрование личных файлов и папок для защиты от несанкционированного доступа."
              features={[
                'Шифрование AES-256',
                'Защита паролем',
                'Скрытие файлов',
                'Безопасное удаление',
              ]}
              tier="pro_plus"
            />
            <FeatureCard
              icon="🔎"
              title="Антишпионское ПО"
              description="Обнаружение и удаление шпионских программ, keyloggers и другого вредоносного ПО."
              features={[
                'Сканирование в реальном времени',
                'База из 1М+ угроз',
                'Карантин подозрительных файлов',
                'Эвристический анализ',
              ]}
              tier="pro_plus"
            />
          </div>
        </div>

        {/* Advanced Features */}
        <div className="mb-20">
          <div className="flex items-center gap-4 mb-8">
            <span className="text-6xl">⚙️</span>
            <h2 className="text-4xl font-bold text-white">Расширенные возможности</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <FeatureCard
              icon="📊"
              title="Расширенная аналитика"
              description="Детальный мониторинг системы и анализ производительности в реальном времени."
              features={[
                'Графики производительности',
                'История изменений',
                'Прогнозирование проблем',
                'Детальные отчеты',
              ]}
              tier="pro_plus"
            />
            <FeatureCard
              icon="🤖"
              title="Автоматическая оптимизация"
              description="Планировщик автоматической оптимизации по расписанию."
              features={[
                'Настройка расписания',
                'Автозапуск при загрузке',
                'Оптимизация в фоне',
                'Email уведомления',
              ]}
              tier="pro"
            />
            <FeatureCard
              icon="💾"
              title="Резервное копирование"
              description="Автоматическое создание точек восстановления перед оптимизацией."
              features={[
                'Точки восстановления',
                'Откат изменений',
                'Облачное хранение',
                'Версионирование',
              ]}
              tier="pro_plus"
            />
            <FeatureCard
              icon="📱"
              title="Мультиустройства"
              description="Управление неограниченным количеством устройств из одного аккаунта."
              features={[
                'Синхронизация настроек',
                'Удаленное управление',
                'Единая панель управления',
                'История всех устройств',
              ]}
              tier="pro_plus"
            />
          </div>
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-md p-12 rounded-3xl border border-white/20 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Готовы оптимизировать свой ПК?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Начните с бесплатной версии или получите полный доступ с Pro
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/app"
              className="bg-white/20 hover:bg-white/30 text-white px-8 py-4 rounded-xl font-semibold transition"
            >
              Попробовать бесплатно
            </Link>
            <Link
              href="/pricing"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-semibold transition"
            >
              Смотреть тарифы
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 py-8 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>© 2024 PC Optimizer Pro. Все права защищены.</p>
        </div>
      </footer>
    </div>
  );
}

interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
  features: string[];
  tier: 'free' | 'pro' | 'pro_plus';
}

function FeatureCard({ icon, title, description, features, tier }: FeatureCardProps) {
  const tierColors = {
    free: 'border-gray-400/30 bg-gray-600/10',
    pro: 'border-blue-400/30 bg-blue-600/10',
    pro_plus: 'border-yellow-400/30 bg-yellow-600/10',
  };

  const tierLabels = {
    free: '🆓 Free',
    pro: '💎 Pro',
    pro_plus: '⭐ Pro Plus',
  };

  return (
    <div className={`bg-white/10 backdrop-blur-md p-6 rounded-2xl border ${tierColors[tier]} hover:border-white/40 transition`}>
      <div className="flex items-start justify-between mb-4">
        <span className="text-5xl">{icon}</span>
        <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
          tier === 'free' ? 'bg-gray-600 text-white' :
          tier === 'pro' ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' :
          'bg-gradient-to-r from-yellow-600 to-orange-600 text-white'
        }`}>
          {tierLabels[tier]}
        </span>
      </div>
      <h3 className="text-2xl font-bold text-white mb-3">{title}</h3>
      <p className="text-gray-300 mb-4">{description}</p>
      <ul className="space-y-2">
        {features.map((feature, idx) => (
          <li key={idx} className="flex items-start gap-2 text-gray-300 text-sm">
            <span className="text-green-400 mt-1">✓</span>
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
