# 📦 Создание EXE версии приложения

Это веб-приложение можно упаковать в настоящий Windows EXE файл несколькими способами:

## Метод 1: Electron (Рекомендуется)

### Преимущества:
- ✅ Полноценное настольное приложение
- ✅ Доступ к системным API
- ✅ Автообновления
- ✅ Встроенный Chromium

### Установка:

```bash
# Установите Electron
npm install --save-dev electron electron-builder

# Установите дополнительные пакги
npm install --save-dev concurrently wait-on cross-env
```

### Создайте файл `electron/main.js`:

```javascript
const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    icon: path.join(__dirname, 'icon.ico'),
  });

  // В разработке
  if (process.env.NODE_ENV === 'development') {
    win.loadURL('http://localhost:3000');
    win.webContents.openDevTools();
  } else {
    // В production
    win.loadFile('out/index.html');
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
```

### Добавьте в `package.json`:

```json
{
  "main": "electron/main.js",
  "scripts": {
    "electron": "electron .",
    "electron:dev": "concurrently \"npm run dev\" \"wait-on http://localhost:3000 && electron .\"",
    "electron:build": "npm run build && electron-builder"
  },
  "build": {
    "appId": "com.pcoptimizer.pro",
    "productName": "PC Optimizer Pro",
    "directories": {
      "output": "dist"
    },
    "files": [
      "out/**/*",
      "electron/**/*"
    ],
    "win": {
      "target": ["nsis"],
      "icon": "electron/icon.ico"
    },
    "nsis": {
      "oneClick": false,
      "allowToChangeInstallationDirectory": true,
      "createDesktopShortcut": true,
      "createStartMenuShortcut": true
    }
  }
}
```

### Сборка EXE:

```bash
# Экспорт статических файлов Next.js
npm run build

# Сборка Electron приложения
npm run electron:build
```

Результат будет в папке `dist/`

---

## Метод 2: Tauri (Современный подход)

### Преимущества:
- ✅ Меньший размер (10-20 MB вместо 100+ MB)
- ✅ Быстрее Electron
- ✅ Использует системный WebView
- ✅ Написан на Rust

### Установка:

```bash
# Установите Tauri CLI
npm install --save-dev @tauri-apps/cli
npm install @tauri-apps/api

# Инициализация Tauri
npx tauri init
```

При настройке укажите:
- Build command: `npm run build`
- Dev command: `npm run dev`
- Dev path: `http://localhost:3000`
- Dist directory: `.next` или `out` (если используете static export)

### Сборка:

```bash
npm run tauri build
```

---

## Метод 3: Neutralino (Легковесный)

### Преимущества:
- ✅ Очень маленький размер (2-3 MB)
- ✅ Минимальные ресурсы
- ✅ Кроссплатформенность

### Установка:

```bash
npm install -g @neutralinojs/neu
neu create myapp
```

---

## Метод 4: PWA to EXE (Простой)

### С помощью PWA Builder:

1. Убедитесь что ваше приложение работает как PWA
2. Создайте `manifest.json`
3. Используйте [PWABuilder](https://www.pwabuilder.com/)
4. Загрузите ваш сайт
5. Скачайте Windows пакет

---

## 🎨 Создание иконки

Создайте файл `icon.ico` с разрешениями:
- 16x16
- 32x32
- 48x48
- 64x64
- 128x128
- 256x256

Используйте онлайн конвертеры или:
```bash
# С помощью ImageMagick
convert icon.png -define icon:auto-resize=256,128,64,48,32,16 icon.ico
```

---

## 📋 Создание разных версий (Free, Pro, Pro Plus)

### Вариант 1: Отдельные сборки

В `package.json` создайте разные скрипты:

```json
{
  "scripts": {
    "build:free": "NEXT_PUBLIC_VERSION=free npm run build",
    "build:pro": "NEXT_PUBLIC_VERSION=pro npm run build",
    "build:pro-plus": "NEXT_PUBLIC_VERSION=pro_plus npm run build",
    "electron:build:free": "NEXT_PUBLIC_VERSION=free npm run electron:build",
    "electron:build:pro": "NEXT_PUBLIC_VERSION=pro npm run electron:build",
    "electron:build:pro-plus": "NEXT_PUBLIC_VERSION=pro_plus npm run electron:build"
  }
}
```

### Вариант 2: Один билд с активацией

Создайте один EXE, но с системой лицензий:
- При первом запуске пользователь вводит ключ
- Ключ определяет какая версия активируется
- Функции блокируются/разблокируются соответственно

---

## 🔧 Настройка установщика NSIS

Создайте файл `installer.nsi`:

```nsis
!define APP_NAME "PC Optimizer Pro"
!define COMP_NAME "Your Company"
!define VERSION "2.5.1.0"
!define COPYRIGHT "Your Company © 2024"
!define DESCRIPTION "PC Optimization Tool"
!define INSTALLER_NAME "PCOptimizerPro-Setup.exe"
!define MAIN_APP_EXE "PCOptimizerPro.exe"
!define INSTALL_DIR "$PROGRAMFILES64\\${APP_NAME}"

VIProductVersion  "${VERSION}"
VIAddVersionKey "ProductName"  "${APP_NAME}"
VIAddVersionKey "CompanyName"  "${COMP_NAME}"
VIAddVersionKey "LegalCopyright"  "${COPYRIGHT}"
VIAddVersionKey "FileDescription"  "${DESCRIPTION}"
VIAddVersionKey "FileVersion"  "${VERSION}"

SetCompressor ZLIB
Name "${APP_NAME}"
Caption "${APP_NAME}"
OutFile "${INSTALLER_NAME}"
BrandingText "${APP_NAME}"
InstallDir "${INSTALL_DIR}"

Section "MainSection" SEC01
    SetOutPath "$INSTDIR"
    SetOverwrite ifnewer
    File /r "dist\\*.*"
    
    CreateDirectory "$SMPROGRAMS\\${APP_NAME}"
    CreateShortCut "$SMPROGRAMS\\${APP_NAME}\\${APP_NAME}.lnk" "$INSTDIR\\${MAIN_APP_EXE}"
    CreateShortCut "$DESKTOP\\${APP_NAME}.lnk" "$INSTDIR\\${MAIN_APP_EXE}"
SectionEnd
```

---

## 🚀 Автообновления

### С Electron:

```bash
npm install electron-updater
```

В `main.js`:

```javascript
const { autoUpdater } = require('electron-updater');

app.on('ready', () => {
  autoUpdater.checkForUpdatesAndNotify();
});

autoUpdater.on('update-downloaded', () => {
  autoUpdater.quitAndInstall();
});
```

---

## 📦 Итоговая структура файлов для скачивания

После сборки у вас будут:

```
downloads/
├── PCOptimizerPro-Free-Setup.exe     (45 MB)
├── PCOptimizerPro-Pro-Setup.exe      (52 MB)
└── PCOptimizerPro-ProPlus-Setup.exe  (68 MB)
```

---

## 🎯 Рекомендации

1. **Для начала:** Используйте Electron - проще всего
2. **Для оптимизации:** Перейдите на Tauri
3. **Для максимальной легковесности:** Neutralino

---

## ⚠️ Важно

- Подпишите ваше приложение сертификатом (code signing)
- Добавьте антивирусные исключения в документацию
- Протестируйте на разных версиях Windows
- Добавьте логирование ошибок (Sentry, LogRocket)
- Настройте аналитику (Google Analytics, Mixpanel)

---

## 📝 Дополнительные ресурсы

- [Electron Documentation](https://www.electronjs.org/docs)
- [Tauri Documentation](https://tauri.app/)
- [Neutralino Documentation](https://neutralino.js.org/)
- [NSIS Documentation](https://nsis.sourceforge.io/Docs/)
