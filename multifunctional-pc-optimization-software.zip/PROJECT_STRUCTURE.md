# 📁 Структура проекта PC Optimizer Pro

## 🗂️ Файловая структура

```
pc-optimizer-pro/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── api/                      # API endpoints
│   │   │   ├── auth/                 # Аутентификация
│   │   │   │   ├── login/route.ts    # Вход в систему
│   │   │   │   └── register/route.ts # Регистрация
│   │   │   ├── health/route.ts       # Health check
│   │   │   ├── optimize/route.ts     # История оптимизации
│   │   │   └── subscription/
│   │   │       └── upgrade/route.ts  # Обновление подписки
│   │   ├── app/                      # Приложение оптимизации
│   │   │   └── page.tsx             # Главная страница приложения
│   │   ├── dashboard/                # Личный кабинет
│   │   │   └── page.tsx
│   │   ├── download/                 # Страница скачивания
│   │   │   └── page.tsx
│   │   ├── features/                 # Описание возможностей
│   │   │   └── page.tsx
│   │   ├── login/                    # Авторизация
│   │   │   └── page.tsx
│   │   ├── pricing/                  # Тарифы
│   │   │   └── page.tsx
│   │   ├── globals.css              # Глобальные стили
│   │   ├── layout.tsx               # Главный layout
│   │   └── page.tsx                 # Главная страница (лендинг)
│   └── db/
│       ├── index.ts                 # Подключение к БД
│       └── schema.ts                # Схема базы данных
├── public/
│   └── manifest.json                # PWA manifest
├── .env                             # Переменные окружения
├── drizzle.config.json              # Конфигурация Drizzle
├── next.config.ts                   # Конфигурация Next.js
├── package.json                     # Зависимости проекта
├── tailwind.config.ts               # Конфигурация Tailwind
├── tsconfig.json                    # Конфигурация TypeScript
├── README.md                        # Документация
├── HOW_TO_CREATE_EXE.md            # Инструкция создания EXE
└── PROJECT_STRUCTURE.md             # Этот файл
```

## 📄 Описание страниц

### 🏠 Главная страница (/)
**Файл:** `src/app/page.tsx`
**Описание:** Лендинг с презентацией продукта, тарифами и кнопками скачивания

**Секции:**
- Hero секция с главным заголовком
- Преимущества (3 карточки)
- Тарифы (Free, Pro, Pro Plus)
- Секция скачивания
- Footer

### 🖥️ Приложение оптимизации (/app)
**Файл:** `src/app/app/page.tsx`
**Описание:** Основное приложение с вкладками и функциями оптимизации

**Вкладки:**
1. **🖥️ Система** - Очистка файлов, реестра, автозагрузка
2. **🌐 Интернет** - DNS, кэш, TCP/IP, VPN
3. **🔒 Приватность** - История, трекеры, защита данных
4. **⚡ Производительность** - Мониторинг системы
5. **⚙️ Дополнительно** - Планировщик, резервные копии

**Компоненты:**
- Тактильные переключатели (ToggleCard)
- Блокировка функций по подписке
- Индикатор прогресса оптимизации
- Статистика в сайдбаре

### 🔐 Авторизация (/login)
**Файл:** `src/app/login/page.tsx`
**Описание:** Форма входа и регистрации

**Функции:**
- Переключение между входом и регистрацией
- Валидация форм
- Интеграция с API

### 💎 Тарифы (/pricing)
**Файл:** `src/app/pricing/page.tsx`
**Описание:** Детальная информация о тарифных планах

**Секции:**
- Карточки тарифов с ценами
- Сравнительная таблица функций
- FAQ секция

### 📥 Скачивание (/download)
**Файл:** `src/app/download/page.tsx`
**Описание:** Страница скачивания приложения

**Секции:**
- Выбор версии (Free, Pro, Pro Plus)
- Кнопки скачивания
- Системные требования
- История изменений
- Инструкция по установке

### ⭐ Возможности (/features)
**Файл:** `src/app/features/page.tsx`
**Описание:** Детальное описание всех функций

**Категории:**
- Оптимизация системы (4 функции)
- Оптимизация интернета (4 функции)
- Конфиденциальность (4 функции)
- Расширенные возможности (4 функции)

### 📊 Дэшборд (/dashboard)
**Файл:** `src/app/dashboard/page.tsx`
**Описание:** Личный кабинет пользователя

**Секции:**
- Статистика использования (4 метрики)
- Информация о подписке
- Последняя активность
- Быстрые действия
- Статус системы

## 🔌 API Endpoints

### POST /api/auth/register
**Описание:** Регистрация нового пользователя
**Тело запроса:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "Имя Пользователя"
}
```
**Ответ:**
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "Имя Пользователя",
    "subscription": "free"
  }
}
```

### POST /api/auth/login
**Описание:** Вход в систему
**Тело запроса:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

### POST /api/optimize
**Описание:** Сохранение истории оптимизации
**Тело запроса:**
```json
{
  "userId": "uuid",
  "action": "Очистка временных файлов",
  "category": "system"
}
```

### GET /api/optimize?userId=uuid
**Описание:** Получение истории оптимизации пользователя

### POST /api/subscription/upgrade
**Описание:** Обновление подписки
**Тело запроса:**
```json
{
  "userId": "uuid",
  "subscription": "pro"
}
```

## 🗄️ Схема базы данных

### Таблица: users
```typescript
{
  id: UUID,              // Уникальный идентификатор
  email: VARCHAR(255),   // Email (уникальный)
  name: VARCHAR(255),    // Имя пользователя
  password: VARCHAR(255), // Хэш пароля
  subscription: VARCHAR(50), // free | pro | pro_plus
  subscriptionExpiry: TIMESTAMP, // Дата окончания
  createdAt: TIMESTAMP   // Дата регистрации
}
```

### Таблица: optimizationHistory
```typescript
{
  id: UUID,              // Уникальный идентификатор
  userId: UUID,          // Связь с users.id
  action: VARCHAR(255),  // Название действия
  category: VARCHAR(100), // Категория (system, network, etc.)
  timestamp: TIMESTAMP,  // Время выполнения
  success: BOOLEAN       // Успешность операции
}
```

## 🎨 Дизайн система

### Цветовая палитра
- **Фон:** `bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900`
- **Карточки:** `bg-white/10 backdrop-blur-md`
- **Границы:** `border border-white/20`
- **Текст:** `text-white`, `text-gray-300`
- **Акценты:** `from-blue-600 to-purple-600`

### Компоненты

#### Тактильный переключатель
```tsx
<button className={`relative w-14 h-8 rounded-full transition ${
  enabled ? 'bg-gradient-to-r from-blue-600 to-purple-600' : 'bg-gray-600'
}`}>
  <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition transform ${
    enabled ? 'translate-x-6' : 'translate-x-0'
  }`}></div>
</button>
```

#### Карточка функции
```tsx
<div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
  {/* Контент */}
</div>
```

#### Градиентная кнопка
```tsx
<button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-semibold transition">
  Текст кнопки
</button>
```

## 📦 Зависимости

### Основные
- **next:** ^16.2.5 - React фреймворк
- **react:** ^19 - UI библиотека
- **drizzle-orm:** - ORM для PostgreSQL
- **postgres:** - PostgreSQL клиент

### Dev зависимости
- **typescript:** - Типизация
- **tailwindcss:** - CSS фреймворк
- **@types/node:** - Типы Node.js
- **@types/react:** - Типы React

## 🚀 Скрипты

```json
{
  "dev": "next dev",           // Режим разработки
  "build": "next build",       // Production сборка
  "start": "next start",       // Production сервер
  "typecheck": "tsc --noEmit"  // Проверка типов
}
```

## 🔧 Конфигурация

### Environment Variables (.env)
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

### Tailwind Config
- Расширенная палитра цветов
- Кастомные анимации
- Backdrop blur поддержка

### Next.js Config
- App Router включен
- Image optimization
- Environment variables

## 🎯 Особенности реализации

### Система подписок
- 3 уровня: Free, Pro, Pro Plus
- Блокировка функций по подписке
- `isFeatureLocked()` функция
- Визуальные индикаторы блокировки

### PWA поддержка
- manifest.json
- Service Worker (опционально)
- Установка как приложение
- Offline поддержка (опционально)

### Безопасность
⚠️ **Для production:**
- Хеширование паролей (bcrypt)
- JWT токены
- CORS настройка
- Rate limiting
- HTTPS обязателен

## 📱 Адаптивность

Все страницы полностью адаптивны:
- Mobile (320px+)
- Tablet (768px+)
- Desktop (1024px+)
- Large Desktop (1920px+)

## 🎨 Анимации

- Hover эффекты
- Transform transitions
- Backdrop blur
- Gradient animations
- Progress bars
- Loading states

## 🔄 Следующие шаги

1. **Добавить настоящую аутентификацию**
   - JWT токены
   - Refresh tokens
   - Password hashing

2. **Интегрировать платежную систему**
   - Stripe или Cloudpayments
   - Subscription management
   - Webhooks

3. **Создать EXE версию**
   - Electron packaging
   - Auto-updates
   - Installer creation

4. **Добавить реальную функциональность**
   - Windows API интеграция
   - System optimization scripts
   - Network tools

5. **Аналитика и мониторинг**
   - Google Analytics
   - Error tracking (Sentry)
   - Performance monitoring

---

**Версия:** 1.0.0
**Дата:** 2024
**Автор:** PC Optimizer Pro Team
